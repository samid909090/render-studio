// The one continuous world: a village lane sloping down to a market square.
// Pure function of nothing but its props — no state, no randomness (seeded layout constants only).
import React from "react";
import { boxG, cylG, Label, M, sphG } from "../inkbeat/core/kit";
import type { V3 } from "../inkbeat/types";
import { Awning, Barrel, Crate, House } from "../demo/Street";

/** ground height: a 0.15 slope from the hilltop down to z = -4, flat market below */
export const groundY = (z: number) => (z >= -4 ? (z + 4) * 0.15 : 0);
export const SLOPE = Math.atan(0.15);

/** terrain: two boxes only — one flat (the market), one tilted (the hillside). groundY is piecewise
 *  linear with a single break at z = -4, so two boxes trace it exactly, with no segment seams. */
const Terrain: React.FC = () => (
  <group>
    <M g={boxG(46, 0.3, 22.3)} c="#79a85b" p={[0, -0.15, -15.1]} cast={false} />
    <M g={boxG(46, 0.3, 30.34)} c="#79a85b" p={[0, 2.1, 11]} r={[-SLOPE, 0, 0]} cast={false} />
  </group>
);

/** the dirt lane: a thin strip riding just above the terrain, same two-piece construction */
const Lane: React.FC = () => (
  <group>
    <M g={boxG(5.6, 0.1, 4.4)} c="#b28c58" tex="fabric" ts={2.5} p={[0, -0.02, -6.1]} cast={false} />
    <M g={boxG(5.6, 0.1, 30.34)} c="#b28c58" tex="fabric" ts={2.5} p={[0, 2.23, 11]} r={[-SLOPE, 0, 0]} cast={false} />
    {/* market square paving */}
    <M g={boxG(24, 0.05, 15)} c="#a89a86" tex="stone" ts={3} p={[0, 0.026, -11.5]} cast={false} />
  </group>
);

const Tree: React.FC<{ p: V3; s?: number }> = ({ p, s = 1 }) => (
  <group position={p} scale={s}>
    <M g={cylG(0.14, 0.2, 1.6, 10)} c="#6b4a30" tex="wood" p={[0, 0.8, 0]} />
    <M g={sphG(1.15, 18)} c="#4e8a44" tex="fabric" p={[0, 2.2, 0]} />
    <M g={sphG(0.85, 16)} c="#5c9a4e" tex="fabric" p={[0.7, 1.75, 0.25]} />
    <M g={sphG(0.7, 16)} c="#437a3a" tex="fabric" p={[-0.65, 1.8, -0.2]} />
  </group>
);

/** a house on a stone pad cut into the slope (pad top = groundY at the house z) */
const SlopeHouse: React.FC<{ x: number; z: number; yaw: number; wall: string; tex: "plaster" | "brick" | "planks"; roof: string; w?: number; h?: number }> = ({ x, z, yaw, wall, tex, roof, w = 5, h = 5 }) => {
  const y = groundY(z);
  return (
    <group>
      <M g={boxG(w + 1.2, 1.6, 5.4)} c="#8a7a68" tex="stone" p={[x, y - 0.81, z]} cast={false} />
      <House p={[x, y - 0.02, z]} w={w} h={h} d={4} wall={wall} tex={tex} roof={roof} yaw={yaw} windows={2} />
    </group>
  );
};

/** one market stall: posts, counter, striped awning, crates and produce */
export const Stall: React.FC<{ p: V3; yaw: number; color: string; goods: string[] }> = ({ p, yaw, color, goods }) => (
  <group position={p} rotation={[0, yaw, 0]}>
    {[-1.5, 1.5].map((x) =>
      [-0.7, 0.7].map((z) => <M key={`${x}${z}`} g={cylG(0.05, 0.05, 2.5, 8)} c="#6b4a30" tex="wood" p={[x, 1.25, z]} />)
    )}
    <M g={boxG(3.4, 0.12, 1.7)} c="#8a5f36" tex="planks" p={[0, 0.95, 0]} />
    <M g={boxG(3.4, 0.85, 1.55)} c="#a06a3c" tex="planks" p={[0, 0.45, 0]} />
    <group position={[0, 2.62, -0.85]}>
      <Awning p={[0, 0, 0]} w={3.8} color={color} />
    </group>
    <Crate p={[-1.0, 1.01, 0.1]} s={0.52} yaw={0.2} />
    <Crate p={[0.15, 1.01, -0.15]} s={0.44} yaw={-0.3} />
    {goods.map((c, i) => (
      <M key={i} g={sphG(0.13, 12)} c={c} p={[-1.15 + (i % 3) * 0.24, 1.36 + Math.floor(i / 3) * 0.05, 0.08 + (i % 2) * 0.16]} />
    ))}
    <Barrel p={[2.05, 0, 0.5]} />
  </group>
);

/** the painted MARKET board over the lane entrance (sound-off tag #1) */
const MarketSign: React.FC = () => (
  <group>
    {[-3.3, 3.3].map((x) => (
      <M key={x} g={cylG(0.07, 0.09, 3.4, 10)} c="#5a3d26" tex="wood" p={[x, groundY(-5.6) + 1.7, -5.6]} />
    ))}
    <M g={boxG(7.2, 0.14, 0.14)} c="#5a3d26" tex="wood" p={[0, groundY(-5.6) + 3.32, -5.6]} />
    <Label text="MARKET" p={[0, groundY(-5.6) + 2.78, -5.52]} w={3.4} h={0.78} fg="#f4ead6" bg="#3a2a4a" font={0.62} />
  </group>
);

export const World: React.FC = () => (
  <group>
    <Terrain />
    <Lane />
    {/* hilltop + lane-side houses */}
    <SlopeHouse x={8.8} z={15.8} yaw={-0.5} wall="#f0c89a" tex="plaster" roof="#9a4a3a" />
    <SlopeHouse x={-7.8} z={9.0} yaw={0.45} wall="#b8604a" tex="brick" roof="#4a4a6a" w={5.4} h={5.8} />
    <SlopeHouse x={8.4} z={3.0} yaw={-0.4} wall="#9ab8c8" tex="plaster" roof="#7a3a3a" w={4.6} h={4.4} />
    {/* market row */}
    <SlopeHouse x={-9.2} z={-15.5} yaw={0.25} wall="#e8dca8" tex="planks" roof="#5a4a6a" />
    <SlopeHouse x={9.4} z={-16.5} yaw={-0.25} wall="#f0c89a" tex="plaster" roof="#9a4a3a" w={5.6} h={6} />
    <SlopeHouse x={-10.5} z={-7.5} yaw={0.9} wall="#c8b8a0" tex="plaster" roof="#6a4a3a" w={4.4} h={4.2} />
    {/* stalls around the square */}
    <Stall p={[-6.9, 0, -10.2]} yaw={Math.PI / 2} color="#c83a3a" goods={["#d84a3a", "#e8a03a", "#d84a3a", "#7aa04a", "#e8a03a", "#d84a3a"]} />
    <Stall p={[7.6, 0, -13.5]} yaw={-Math.PI / 2} color="#3a6ac8" goods={["#7aa04a", "#7aa04a", "#e8d44a", "#7aa04a", "#e8d44a", "#a05ab0"]} />
    <Stall p={[0.6, 0, -17.2]} yaw={0} color="#3a9a6a" goods={["#e8a03a", "#d84a3a", "#e8a03a", "#d84a3a", "#7aa04a", "#e8a03a"]} />
    <MarketSign />
    <Tree p={[-8.5, groundY(19.5), 19.5]} s={1.15} />
    <Tree p={[10.6, groundY(20), 20]} s={1.3} />
    <Tree p={[-9.4, groundY(-1), -1]} s={1.05} />
    <Tree p={[10.2, 0, -6]} s={1.2} />
    <Tree p={[-11, 0, -19]} s={1.25} />
    <Crate p={[3.9, 0, -8.2]} s={0.55} yaw={0.4} />
    <Crate p={[4.45, 0, -8.0]} s={0.42} yaw={-0.2} />
    <Barrel p={[-3.8, 0, -7.6]} />
  </group>
);
