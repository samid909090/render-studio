// Coded props: the grain cart, the hay cart, the hay bales, the brake rope.
// All pure: every animated value arrives as a prop from acting.ts.
import React from "react";
import * as THREE from "three";
import { boxG, coreMat, cylG, Label, M, sphG, torG } from "../inkbeat/core/kit";
import type { V3 } from "../inkbeat/types";

const WOOD = "#8a5f36";
const WOOD_D = "#6e4a2a";

/** one spoked cart wheel, spinning around the x axis */
const Wheel: React.FC<{ x: number; z: number; r: number; spin: number }> = ({ x, z, r, spin }) => (
  <group position={[x, r, z]}>
    <group rotation={[spin, 0, 0]}>
      <group rotation={[0, Math.PI / 2, 0]}>
        <M g={torG(r - 0.05, 0.055)} c={WOOD_D} tex="wood" />
      </group>
      {[0, 1, 2].map((k) => (
        <M key={k} g={boxG(0.07, (r - 0.08) * 2, 0.07)} c={WOOD} tex="wood" r={[k * Math.PI / 3, 0, 0]} />
      ))}
      <M g={cylG(0.11, 0.11, 0.14, 12)} c="#4a4a52" tex="metal" r={[0, 0, Math.PI / 2]} />
    </group>
  </group>
);

const Sack: React.FC<{ p: V3; s?: number; c?: string }> = ({ p, s = 1, c = "#c8a06a" }) => (
  <M g={sphG(0.42, 16)} c={c} tex="fabric" p={p} s={[1.15 * s, 0.58 * s, 1.35 * s]} />
);

/** Karim's grain cart, front toward -z, origin at ground level under the bed centre.
 *  `rope` = the brake rope still tied (pre-snap): a line from the brake lever back to the anchor post. */
export const GrainCart: React.FC<{ spin: number; rope: boolean }> = ({ spin, rope }) => (
  <group>
    <Wheel x={-0.98} z={1.02} r={0.58} spin={spin} />
    <Wheel x={0.98} z={1.02} r={0.58} spin={spin} />
    <Wheel x={-0.98} z={-1.02} r={0.46} spin={spin * 1.26} />
    <Wheel x={0.98} z={-1.02} r={0.46} spin={spin * 1.26} />
    {/* bed */}
    <M g={boxG(1.9, 0.1, 2.9)} c={WOOD} tex="planks" p={[0, 0.82, 0]} />
    <M g={boxG(1.98, 0.14, 3.0)} c={WOOD_D} tex="planks" p={[0, 0.68, 0]} />
    {[-0.92, 0.92].map((x) => (
      <M key={x} g={boxG(0.08, 0.6, 2.9)} c={WOOD} tex="planks" p={[x, 1.15, 0]} />
    ))}
    <M g={boxG(1.9, 0.6, 0.08)} c={WOOD} tex="planks" p={[0, 1.15, -1.42]} />
    <M g={boxG(1.9, 0.6, 0.08)} c={WOOD} tex="planks" p={[0, 1.15, 1.42]} />
    {[-1.38, 1.38].map((z) =>
      [-0.92, 0.92].map((x) => <M key={`${x}${z}`} g={boxG(0.11, 0.85, 0.11)} c={WOOD_D} tex="wood" p={[x, 1.1, z]} />)
    )}
    {/* the load: sacks and a grain heap */}
    <Sack p={[-0.45, 1.28, 0.75]} />
    <Sack p={[0.48, 1.28, 0.7]} c="#b8905a" />
    <Sack p={[-0.42, 1.28, -0.15]} c="#b8905a" />
    <Sack p={[0.45, 1.3, -0.85]} />
    <Sack p={[0, 1.62, 0.25]} s={0.9} />
    <M g={sphG(0.5, 16)} c="#d8a83c" tex="fabric" p={[-0.1, 1.42, -0.45]} s={[1.25, 0.5, 1.1]} />
    {/* dragging shafts at the front */}
    {[-0.55, 0.55].map((x) => (
      <M key={x} g={cylG(0.035, 0.035, 1.5, 8)} c={WOOD_D} tex="wood" p={[x, 0.42, -1.95]} r={[-0.62, 0, 0]} />
    ))}
    {/* brake lever at the rear (sound-off tag #2 on the side) */}
    <M g={cylG(0.03, 0.03, 0.55, 8)} c="#4a4a52" tex="metal" p={[-0.8, 1.3, 1.52]} r={[0.5, 0, 0.3]} />
    {rope ? <RopeTie a={[-0.86, 1.52, 1.66]} b={[-2.2, 1.08, 1.92]} /> : null}
    <Label text="2 TONNES" p={[1.0, 1.12, 0]} r={[0, Math.PI / 2, 0]} w={1.7} h={0.44} fg="#f4ead6" bg="#5a3d26" font={0.6} />
  </group>
);

/** the parked hay cart (static); its bales are separate, animated by acting.ts */
export const HayCart: React.FC = () => (
  <group position={[4.3, 0, -5.0]} rotation={[0, -0.12, 0]}>
    <Wheel x={-1.05} z={0} r={0.5} spin={0} />
    <Wheel x={1.05} z={0} r={0.5} spin={0} />
    <M g={boxG(2.1, 0.1, 2.5)} c={WOOD} tex="planks" p={[0, 0.88, 0]} />
    {[-1.0, 1.0].map((x) => (
      <M key={x} g={boxG(0.07, 0.42, 2.5)} c={WOOD} tex="planks" p={[x, 1.12, 0]} />
    ))}
    {/* the pin: a small lever on the lane side, the thing Dev pulls */}
    <M g={cylG(0.025, 0.025, 0.5, 8)} c="#b03030" tex="metal" p={[1.12, 1.05, 0.7]} r={[0, 0, -0.5]} />
    <M g={sphG(0.05, 10)} c="#b03030" p={[1.24, 1.26, 0.7]} />
  </group>
);

/** one round hay bale (axis along x) */
export const Bale: React.FC<{ p: V3; r: V3 }> = ({ p, r }) => (
  <group position={p} rotation={r}>
    <M g={cylG(0.42, 0.42, 0.95, 18)} c="#d9a83e" tex="fabric" r={[0, 0, Math.PI / 2]} />
    {[-0.28, 0.28].map((x) => (
      <group key={x} position={[x, 0, 0]} rotation={[0, Math.PI / 2, 0]}>
        <M g={torG(0.425, 0.018)} c="#8a6a2a" cast={false} />
      </group>
    ))}
  </group>
);

/** the snapped brake rope, held up in Karim's hand from L10 on: a short frayed length */
export const RopeInHand: React.FC<{ p: V3; yaw: number }> = ({ p, yaw }) => (
  <group position={p} rotation={[0, yaw, 0]}>
    <M g={cylG(0.016, 0.016, 0.55, 6)} c="#a8895a" p={[0.3, 1.32, 0.28]} r={[0.35, 0, 0.5]} cast={false} />
    <M g={cylG(0.013, 0.013, 0.3, 6)} c="#bfa06a" p={[0.42, 1.08, 0.36]} r={[-0.3, 0, 0.9]} cast={false} />
  </group>
);

/** a thin cylinder stretched between two local points (the brake rope, tied) */
export const RopeTie: React.FC<{ a: V3; b: V3 }> = ({ a, b }) => {
  const va = new THREE.Vector3(...a);
  const vb = new THREE.Vector3(...b);
  const dir = vb.clone().sub(va);
  const len = dir.length();
  const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.normalize());
  const mid = va.add(vb).multiplyScalar(0.5);
  return <mesh geometry={cylG(0.016, 0.016, len, 6)} material={coreMat("#a8895a", 0.85)} position={mid} quaternion={q} />;
};

/** the anchor post at the hilltop the brake rope was tied to (always there) */
export const AnchorPost: React.FC = () => (
  <M g={cylG(0.07, 0.09, 0.95, 8)} c={WOOD_D} tex="wood" p={[0, 0.47, 0]} />
);

/** the other half of the snapped rope, lying by the anchor post at the hilltop */
export const RopeOnGround: React.FC = () => (
  <M g={cylG(0.015, 0.015, 0.85, 6)} c="#a8895a" p={[0.25, 0.06, 0.35]} r={[Math.PI / 2, 0, 0.7]} cast={false} />
);
