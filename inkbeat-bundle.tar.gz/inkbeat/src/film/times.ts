// Word/line times from the assembled N1 stem (vo/timings.json, plan_src.py format).
// Every beat and action in the film anchors to these onsets — never to hand-typed seconds.
import timings from "../../vo/timings.json";

type TW = { w: string; t: number; end: number };
const TURNS = (timings as { turns: { turn: number; words: TW[] }[] }).turns;

export const norm = (w: string) => w.toLowerCase().replace(/[^a-z0-9'-]/g, "").replace(/^'+|'+$/g, "");

export const lineStart = (n: number) => TURNS[n - 1].words[0].t;
export const lineEnd = (n: number) => TURNS[n - 1].words[TURNS[n - 1].words.length - 1].end;

/** onset of the nth occurrence of `word` inside line `n` (1-based) */
export const onset = (line: number, word: string, nth = 1) => {
  let k = 0;
  for (const w of TURNS[line - 1].words) {
    if (norm(w.w) === norm(word)) {
      k++;
      if (k === nth) return w.t;
    }
  }
  throw new Error(`onset: line ${line} word ${word} #${nth} not found`);
};

export const T_SNAP = onset(2, "snapped");
export const T_SMASH = onset(8, "smashed");
export const T_END_SPEECH = lineEnd(12);
