// Acting: every position, pose and face as a pure function of t (seconds), anchored to word onsets.
// Story-time note: the cart's run is keyframed to its story appearances (fast charge on L3, approach in the
// background of the crowd/Dev beats, final acceleration into the hay) — cartoon time, one continuous world.
import type { FaceState, Pose } from "../inkbeat/char/Character3D";
import type { V3 } from "../inkbeat/types";
import { groundY } from "./world";
import { lineEnd, lineStart, onset, T_SMASH, T_SNAP } from "./times";

export const clamp = (v: number, a = 0, b = 1) => Math.min(b, Math.max(a, v));
export const sstep = (k: number) => {
  k = clamp(k);
  return k * k * (3 - 2 * k);
};
export const lerp = (a: number, b: number, k: number) => a + (b - a) * k;

type NK = [number, number][];
export const keyLerp = (keys: NK, t: number) => {
  if (t <= keys[0][0]) return keys[0][1];
  for (let i = 0; i < keys.length - 1; i++) {
    const [t0, v0] = keys[i];
    const [t1, v1] = keys[i + 1];
    if (t <= t1) return lerp(v0, v1, sstep((t - t0) / (t1 - t0)));
  }
  return keys[keys.length - 1][1];
};

type PK = [number, V3][];
/** a walker: position along keyframed soles + a walk phase integrated from the path length */
export const makeWalker = (keys: PK, cycle: number) => {
  const N = 400;
  const t0 = keys[0][0];
  const t1 = keys[keys.length - 1][0];
  const pos = (t: number): V3 => {
    if (t <= t0) return keys[0][1];
    for (let i = 0; i < keys.length - 1; i++) {
      const [a, p0] = keys[i];
      const [b, p1] = keys[i + 1];
      if (t <= b) {
        const u = sstep((t - a) / (b - a));
        return [lerp(p0[0], p1[0], u), lerp(p0[1], p1[1], u), lerp(p0[2], p1[2], u)];
      }
    }
    return keys[keys.length - 1][1];
  };
  const cum: number[] = [0];
  let prev = pos(t0);
  for (let i = 1; i <= N; i++) {
    const p = pos(t0 + ((t1 - t0) * i) / N);
    cum.push(cum[i - 1] + Math.hypot(p[0] - prev[0], p[2] - prev[2]));
    prev = p;
  }
  const phase = (t: number) => {
    const u = clamp((t - t0) / (t1 - t0));
    const d = cum[Math.round(u * N)];
    return (d / cycle) * Math.PI * 2;
  };
  const moving = (t: number) => {
    const a = pos(t - 0.06);
    const b = pos(t + 0.06);
    return Math.hypot(b[0] - a[0], b[2] - a[2]) > 0.004;
  };
  return { pos, phase, moving };
};

// ------------------------------------------------------------------ the cart
const CART_KEYS: NK = [
  [0, 12.0], [6.9, 12.0], [7.06, 11.9], [9.0, 9.6], [11.16, 6.4], [15.09, 3.4],
  [20.24, 1.6], [24.07, 0.9], [26.71, 0.1], [T_SMASH, -1.2],
];
export const cartZ = (t: number) => {
  if (t > T_SMASH) return -1.2 + 0.05 * Math.exp(-(t - T_SMASH) * 4.5) * Math.sin((t - T_SMASH) * 30);
  return keyLerp(CART_KEYS, t);
};
export const cartState = (t: number) => {
  const z = cartZ(t);
  return { z, y: groundY(z), spin: (12.0 - cartZ(Math.min(t, T_SMASH))) / 0.58, speed: Math.abs(cartZ(t + 0.05) - cartZ(t - 0.05)) / 0.1 };
};

// ------------------------------------------------------------------ Karim (the carter)
export type ActorState = { pos: V3; yaw: number; face: FaceState; pose: Pose };
const mouthFlap = (t: number, a: number, b: number, on: FaceState["mouth"], off: FaceState["mouth"]): FaceState["mouth"] =>
  t >= a && t <= b ? (Math.floor(t * 7.5) % 2 === 0 ? on : off) : off;

export const karimState = (t: number): ActorState => {
  let pos: V3, yaw: number, pose: Pose = { armL: [12, 12], armR: [14, 12] };
  if (t < 7.5) {
    pos = [-1.7, groundY(13.4), 13.4];
    yaw = 2.3;
    pose = { armL: [12, 12], armR: [58, 28], armRFwd: 22 }; // holding the brake rope
  } else if (t <= 28.9) {
    const z = Math.min(13.4, cartZ(t - 0.4) + 2.7);
    pos = [-1.85, groundY(z), z];
    yaw = Math.PI;
    const run = Math.max(0, 13.4 - z);
    if (run > 0.02) pose = { walk: (run / 1.55) * Math.PI * 2 };
  } else if (t < lineStart(10)) {
    pos = [-1.85, groundY(1.5), 1.5];
    yaw = Math.PI;
  } else if (t <= 38.4) {
    const u = sstep((t - lineStart(10)) / (38.4 - lineStart(10)));
    const x = lerp(-1.85, -1.5, u), z = lerp(1.5, -2.3, u);
    pos = [x, groundY(z), z];
    yaw = 3.05;
    pose = { walk: (Math.hypot(x + 1.85, z - 1.5) / 1.5) * Math.PI * 2 };
  } else {
    pos = [-1.5, groundY(-2.3), -2.3];
    yaw = 2.95;
    pose = t >= onset(10, "holding") ? { armL: [12, 12], armR: [96, 14], armRFwd: 26 } : { armL: [12, 12], armR: [14, 12] };
  }
  let face: FaceState;
  if (t < 6.0) face = { eyes: "open", mouth: "smile", brows: "neutral" };
  else if (t < T_SNAP) face = { eyes: "wide", mouth: "flat", brows: "worried" };
  else if (t < 15.1) face = { eyes: "wide", mouth: "open", brows: "worried", sweat: t > 9 };
  else if (t < lineStart(9)) face = { eyes: "open", mouth: "flat", brows: "worried" };
  else if (t < lineStart(10)) face = { eyes: "open", mouth: "flat", brows: "neutral" };
  else if (t < lineStart(11)) face = { eyes: "open", mouth: "flat", brows: "neutral" };
  else if (t < lineEnd(11)) face = { eyes: "open", mouth: mouthFlap(t, onset(11, "you"), lineEnd(11), "open", "smile"), brows: t >= onset(11, "under") ? "raised" : "neutral" };
  else face = { eyes: "open", mouth: "smile", brows: "neutral" };
  return { pos, yaw, face, pose };
};

// ------------------------------------------------------------------ Dev (the boy)
const devWalker = makeWalker(
  [
    [0, [5.7, 0, -7.3]],
    [lineStart(6), [5.7, 0, -7.3]],
    [22.6, [5.6, 0, -4.7]],
    [25.2, [5.6, 0, -4.7]],
    [27.0, [5.15, 0, -5.3]],
    [50, [5.15, 0, -5.3]],
  ],
  0.95
);
export const devState = (t: number): ActorState => {
  const pos = devWalker.pos(t);
  let yaw = 0.15;
  if (t >= lineStart(6) && t < 25.2) yaw = t < 22.6 ? 0.2 : 2.0;
  else if (t >= 25.2) yaw = -1.0;
  let pose: Pose = { armL: [10, 10], armR: [12, 10] };
  if (devWalker.moving(t)) pose = { walk: devWalker.phase(t) };
  else if (t >= onset(7, "pulled") - 0.15 && t < 25.3) pose = { armL: [10, 10], armR: [82, 14], armRFwd: 52 }; // the pull
  else if (t >= lineStart(9) && t < lineStart(11)) pose = { armL: [8, 8], armR: [10, 8], headNod: 13 }; // blamed: head down
  let face: FaceState;
  if (t < onset(4, "screamed")) face = { eyes: "open", mouth: "smile", brows: "neutral" };
  else if (t < lineStart(5)) face = { eyes: "wide", mouth: "o", brows: "raised" };
  else if (t < lineStart(8)) face = { eyes: "open", mouth: "flat", brows: "neutral" };
  else if (t < lineStart(9)) face = { eyes: "squint", mouth: "flat", brows: "worried", sweat: true };
  else if (t < lineStart(11)) face = { eyes: "open", mouth: "frown", brows: "worried", sweat: t < lineStart(10) };
  else if (t < 42.8) face = { eyes: "open", mouth: "flat", brows: "neutral" };
  else face = { eyes: "open", mouth: "smile", brows: "neutral" };
  return { pos, yaw, face, pose };
};

// ------------------------------------------------------------------ the crowd
export type CrowdCfg = { home: V3; scatter: V3; gather: V3; pointer?: boolean; elder?: boolean };
export const CROWD: CrowdCfg[] = [
  { home: [-4.6, 0, -9.5], scatter: [-6.4, 0, -10.8], gather: [6.7, 0, -6.9] },
  { home: [-2.2, 0, -10.8], scatter: [-3.6, 0, -12.4], gather: [6.5, 0, -7.8] },
  { home: [0.8, 0, -9.2], scatter: [2.0, 0, -11.6], gather: [7.1, 0, -7.6], pointer: true },
  { home: [4.9, 0, -9.8], scatter: [6.8, 0, -11.2], gather: [7.3, 0, -8.3], pointer: true },
  { home: [-1.2, 0, -12.6], scatter: [-2.6, 0, -14.4], gather: [6.9, 0, -6.2] },
  { home: [2.6, 0, -13.0], scatter: [4.4, 0, -14.8], gather: [7.5, 0, -7.0], pointer: true },
  { home: [-5.6, 0, -13.2], scatter: [-7.0, 0, -14.6], gather: [6.3, 0, -7.1], elder: true },
];
const crowdWalkers = CROWD.map((c) => {
  const watch: V3 = [lerp(c.home[0], c.scatter[0], 0.45), 0, lerp(c.home[2], c.scatter[2], 0.45)];
  return makeWalker(
    [
      [0, c.home],
      [onset(4, "screamed"), c.home],
      [13.95, c.scatter],
      [20.2, c.scatter],
      [26.0, watch],
      [32.81, watch],
      [34.6, c.gather],
      [50, c.gather],
    ],
    1.5
  );
});
const yawTo = (from: V3, to: V3) => Math.atan2(to[0] - from[0], to[2] - from[2]);
export const crowdState = (i: number, t: number): ActorState => {
  const w = crowdWalkers[i];
  const pos = w.pos(t);
  const cfg = CROWD[i];
  const yawHome = (i % 3 - 1) * 0.22;
  let yaw = yawHome;
  const devP = devWalker.pos(t);
  const karimP: V3 = [-1.5, 0, -2.3];
  if (t >= 33.0 && t < 36.2) yaw = lerp(yawHome, yawTo(pos, devP), sstep((t - 33.0) / 0.6));
  else if (t >= 36.2) yaw = lerp(yawTo(pos, devP), yawTo(pos, karimP), sstep((t - 36.2) / 0.6));
  let pose: Pose = { armL: [12, 12], armR: [12, 12] };
  if (w.moving(t)) pose = { walk: w.phase(t) };
  else if (t >= onset(4, "screamed") && t < 14.7) pose = { armL: [138, 16], armR: [138, 16], armLFwd: 6, armRFwd: 6 }; // arms up, screaming
  else if (cfg.pointer && t >= lineStart(9) && t < 36.2) pose = { armL: [14, 10], armR: [88, 8], armRFwd: 62 }; // pointing at Dev
  let face: FaceState;
  if (t < onset(4, "screamed")) face = { eyes: "open", mouth: i % 2 ? "flat" : "smile", brows: "neutral" };
  else if (t < 15.1) face = { eyes: "wide", mouth: i % 2 ? "open" : "yell", brows: "raised" };
  else if (t < T_SMASH) face = { eyes: "open", mouth: "flat", brows: "worried" };
  else if (t < lineStart(9)) face = { eyes: "wide", mouth: "o", brows: "raised" };
  else if (t < lineStart(10)) face = { eyes: "open", mouth: "frown", brows: "angry" };
  else if (t < 42.8) face = { eyes: "open", mouth: "flat", brows: "neutral" };
  else face = { eyes: "open", mouth: "smile", brows: "neutral" };
  return { pos, yaw, face, pose };
};

// ------------------------------------------------------------------ the hay bales
const BALE_START: V3[] = [
  [3.85, 1.36, -5.35], [4.75, 1.36, -5.35], [3.85, 1.36, -4.55],
  [4.75, 1.36, -4.55], [4.3, 2.08, -5.3], [4.3, 2.08, -4.6],
];
const BALE_END: V3[] = [
  [-1.8, 0.54, -3.2], [-0.9, 0.54, -3.2], [0.0, 0.54, -3.2],
  [0.9, 0.54, -3.2], [1.8, 0.54, -3.2], [-0.45, 1.26, -3.2],
];
export const baleState = (i: number, t: number): { p: V3; r: V3 } => {
  const s = onset(7, "tumbled") - 0.45 + i * 0.13;
  const a = BALE_START[i], b = BALE_END[i];
  if (t < s) return { p: a, r: [0, i * 0.13, 0] };
  const u = clamp((t - s) / 1.15);
  if (u >= 1) {
    const j = t > T_SMASH && t < T_SMASH + 0.7 ? 0.05 * Math.sin((t - T_SMASH) * 36) * Math.exp(-(t - T_SMASH) * 6) : 0;
    return { p: [b[0], b[1], b[2] + j], r: [-(b[2] - a[2]) / 0.42, i * 0.13, 0] };
  }
  const e = sstep(u);
  const p: V3 = [lerp(a[0], b[0], e), lerp(a[1], b[1], e) + Math.sin(u * Math.PI) * 0.45, lerp(a[2], b[2], e)];
  return { p, r: [-((p[2] - a[2]) / 0.42), i * 0.13, Math.sin(u * Math.PI) * 0.18 * (i % 2 ? -1 : 1)] };
};
