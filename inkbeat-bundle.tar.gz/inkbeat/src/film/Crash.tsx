// "The Crash That Saved the Market" — a 50 s inkbeat Short.
// ONE world, ONE camera: the template's beat rig (core/rig.ts poseAt) folds every beat from the opening
// lens — reframes are `to` beats (moves), never cuts. Captions are the template's own (core/captions.tsx),
// planned word-anchored by plan/plan_crash.py. L12 is narration over a hook board: no captions, nobody speaks.
import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { CAST } from "../inkbeat/char/cast";
import { Character3D, headOf } from "../inkbeat/char/Character3D";
import type { CharacterSpec } from "../inkbeat/char/Character3D";
import { CLOTH, HAIR, SKIN } from "../inkbeat/char/family";
import { Captions, makeChunks } from "../inkbeat/core/captions";
import type { Word } from "../inkbeat/core/captions";
import { CastLight } from "../inkbeat/core/castLight";
import { subFrame, useFonts } from "../inkbeat/core/frame";
import { moodOf } from "../inkbeat/core/moods";
import type { MoodPreset } from "../inkbeat/core/moods";
import { poseAt, withShake } from "../inkbeat/core/rig";
import type { Beat, BeatPrm, Cam } from "../inkbeat/core/rig";
import { View } from "../inkbeat/core/View";
import type { V3 } from "../inkbeat/types";
import { ACCENT_WORDS, WORDS } from "../plan.gen";
import { baleState, cartState, crowdState, devState, karimState } from "./acting";
import { AnchorPost, Bale, GrainCart, HayCart, RopeInHand, RopeOnGround } from "./props";
import { lineEnd, lineStart, onset, T_SMASH, T_SNAP } from "./times";
import { groundY, SLOPE, World } from "./world";

// ------------------------------------------------------------------ cast (one family, cast.ts overrides)
const KARIM: CharacterSpec = {
  ...CAST.adult,
  look: {
    ...CAST.adult.look,
    outfit: "vest",
    colors: { top: CLOTH.brick, inner: CLOTH.cream, bottom: CLOTH.khaki, shoes: CLOTH.chestnut, accent: CLOTH.brass },
    seed: 11,
  },
};
const DEV: CharacterSpec = CAST.kid;
const CROWD_SPECS: CharacterSpec[] = [
  { ...CAST.adult, height: 1.7, look: { ...CAST.adult.look, outfit: "sweater", colors: { top: CLOTH.sage, inner: CLOTH.cream, bottom: CLOTH.khaki, shoes: CLOTH.chestnut, accent: CLOTH.horn }, hair: "bun", hairColor: HAIR.auburn, skin: SKIN.light, seed: 21 } },
  { ...CAST.adult, height: 1.76, look: { ...CAST.adult.look, outfit: "shirt", colors: { top: CLOTH.cobalt, inner: CLOTH.cream, bottom: CLOTH.charcoal, shoes: CLOTH.oxblood, accent: CLOTH.horn }, hair: "swoop", hairColor: HAIR.black, skin: SKIN.tan, seed: 22 } },
  { ...CAST.adult, height: 1.72, look: { ...CAST.adult.look, outfit: "vest", colors: { top: CLOTH.mustard, inner: CLOTH.cream, bottom: CLOTH.cocoa, shoes: CLOTH.chestnut, accent: CLOTH.brass }, hair: "curly", hairColor: HAIR.espresso, skin: SKIN.brown, seed: 23 } },
  { ...CAST.adult, height: 1.8, look: { ...CAST.adult.look, outfit: "jacket", colors: { top: CLOTH.brick, inner: CLOTH.cream, bottom: CLOTH.denim, shoes: CLOTH.oxblood, accent: CLOTH.horn }, hair: "swoop", hairColor: HAIR.honey, skin: SKIN.medium, seed: 24 } },
  { ...CAST.adult, height: 1.66, look: { ...CAST.adult.look, outfit: "sweater", colors: { top: CLOTH.rose, inner: CLOTH.cream, bottom: CLOTH.charcoal, shoes: CLOTH.chestnut, accent: CLOTH.horn }, hair: "bun", hairColor: HAIR.espresso, skin: SKIN.fair, seed: 25 } },
  { ...CAST.adult, height: 1.74, look: { ...CAST.adult.look, outfit: "shirt", colors: { top: CLOTH.teal, inner: CLOTH.cream, bottom: CLOTH.khaki, shoes: CLOTH.oxblood, accent: CLOTH.brass }, hair: "curly", hairColor: HAIR.black, skin: SKIN.deep, seed: 26 } },
  { ...CAST.elder, look: { ...CAST.elder.look, colors: { top: CLOTH.cobalt, inner: CLOTH.rose, bottom: CLOTH.cocoa, shoes: CLOTH.chestnut, accent: CLOTH.cream }, seed: 27 } },
];

// ------------------------------------------------------------------ camera: setups + word-anchored beats
const S1: Cam = { pos: [5.4, 5.8, 21.8], look: [-0.4, 2.55, 11.6], fov: 57 };
const S2: Cam = { pos: [5.8, 3.6, 11.8], look: [0, 1.95, 7.8], fov: 55 };
const S3: Cam = { pos: [5.6, 2.1, -15.8], look: [0, 1.5, -4.5], fov: 57 };
const S4: Cam = { pos: [6.6, 1.7, -2.2], look: [5.7, 1.02, -7.3], fov: 48 };
const S5: Cam = { pos: [7.2, 1.6, -0.4], look: [4.4, 0.85, -5.4], fov: 54 };
const S6: Cam = { pos: [-5.4, 0.95, -8.6], look: [0.2, 0.95, -2.4], fov: 60 };
const S7: Cam = { pos: [10.4, 2.3, -9.6], look: [4.9, 1.0, -5.8], fov: 56 };
const S8: Cam = { pos: [3.0, 1.9, -6.4], look: [-1.35, 1.3, -1.7], fov: 50 };

const BEATS: Beat[] = [
  { t: onset(1, "rolled") - 0.2, move: "PUSH", dur: 0.63, word: "rolled" },
  { t: onset(2, "morning") - 0.2, move: "ORBIT_R", dur: 0.7, word: "morning" },
  { t: T_SNAP - 0.2, move: "PUNCH", dur: 0.2, word: "snapped" },
  { t: T_SNAP + 0.02, move: "SHAKE", dur: 0.4 },
  { t: lineStart(3) - 0.25, move: "PUSH", dur: 1.0, word: "Two" },
  { t: onset(3, "roaring") - 0.2, move: "PUSH", dur: 0.6, word: "roaring" },
  { t: onset(3, "stalls") - 0.2, move: "ORBIT_L", dur: 0.7, word: "stalls" },
  { t: lineStart(4) - 0.25, move: "PUSH", dur: 1.0, word: "People" },
  { t: onset(4, "screamed") - 0.2, move: "ORBIT_R", dur: 0.63, word: "screamed" },
  { t: onset(4, "ran") - 0.2, move: "PUSH", dur: 0.63, word: "ran" },
  { t: lineStart(5) - 0.25, move: "PUSH", dur: 0.9, word: "No" },
  { t: onset(5, "except") - 0.2, move: "PUSH", dur: 0.63, word: "except" },
  { t: onset(5, "small") - 0.2, move: "ORBIT_L", dur: 0.7, word: "small" },
  { t: lineStart(6) - 0.25, move: "PUSH", dur: 0.95, word: "Dev" },
  { t: onset(6, "straight") - 0.2, move: "PUSH", dur: 0.63, word: "straight" },
  { t: onset(7, "pulled") - 0.2, move: "PUSH", dur: 0.6, word: "pulled" },
  { t: onset(7, "tumbled") - 0.2, move: "PUSH", dur: 0.63, word: "tumbled" },
  { t: lineStart(8) - 0.3, move: "PUSH", dur: 0.9, word: "runaway" },
  { t: T_SMASH - 0.2, move: "PUNCH", dur: 0.2, word: "smashed" },
  { t: T_SMASH, move: "SHAKE", dur: 0.4 },
  { t: onset(8, "stopped") - 0.2, move: "PULL", dur: 0.66, word: "stopped" },
  { t: lineStart(9) - 0.25, move: "PUSH", dur: 0.95, word: "crowd" },
  { t: onset(9, "turned") - 0.2, move: "ORBIT_L", dur: 0.7, word: "turned" },
  { t: onset(9, "caused") - 0.2, move: "PUSH", dur: 0.63, word: "caused" },
  { t: lineStart(10) - 0.25, move: "PUSH", dur: 0.95, word: "Then" },
  { t: onset(10, "holding") - 0.2, move: "PUSH", dur: 0.63, word: "holding" },
  { t: lineStart(11) - 0.2, move: "PUSH", dur: 0.63, word: "Without" },
  { t: onset(11, "under") - 0.2, move: "PUSH", dur: 0.63, word: "under" },
  { t: onset(12, "see") - 0.2, move: "PUSH", dur: 0.8, word: "see" },
];
const PRMS: BeatPrm[] = [
  { frac: 0.12 }, { frac: 0.06 }, { frac: 0.13 }, {},
  { to: S2 }, { frac: 0.16 }, { deg: 10 },
  { to: S3 }, { deg: 12 }, { frac: 0.08 },
  { to: S4 }, { frac: 0.15 }, { deg: 10 },
  { to: S5 }, { frac: 0.08 },
  { frac: 0.12 }, { deg: 10 },
  { to: S6 }, { frac: 0.1 }, {},
  { frac: -0.12 },
  { to: S7 }, { deg: 12 }, { frac: 0.1 },
  { to: S8 }, { frac: 0.1 },
  { frac: 0.08 }, { frac: 0.08 },
  { frac: -0.1 },
];

// ------------------------------------------------------------------ captions (L1–L11 only; L12 is the board)
const CAP_WORDS = (WORDS as unknown as Word[]).filter((w) => w[1] < lineStart(12));
const CHUNKS = makeChunks(CAP_WORDS, 50);
const ACCENT = new Set(ACCENT_WORDS as unknown as string[]);

const clamp01 = (v: number) => Math.min(1, Math.max(0, v));

const HookBoard: React.FC<{ t: number }> = ({ t }) => {
  const t0 = lineStart(12);
  if (t < t0) return null;
  const dim = clamp01((t - t0) / 0.5);
  const q = clamp01((t - onset(12, "What")) / 0.5);
  return (
    <div style={{ position: "absolute", inset: 0 }}>
      <div style={{ position: "absolute", inset: 0, background: `rgba(5,9,16,${0.45 * dim})` }} />
      <div
        style={{
          position: "absolute", left: 84, right: 84, top: 600, opacity: dim,
          background: "#0d1b2e", border: "7px solid #f0b400", borderRadius: 30,
          padding: "54px 48px 48px", textAlign: "center",
          fontFamily: "Poppins", color: "#ffffff",
        }}
      >
        <div style={{ fontSize: 37, fontWeight: 700, lineHeight: 1.35, opacity: clamp01((t - t0 - 0.25) / 0.5) }}>
          The boy they blamed for the crash was the only one who saw it coming.
        </div>
        <div style={{ fontSize: 63, fontWeight: 800, lineHeight: 1.22, color: "#f0b400", marginTop: 40 }}>
          THE CRASH THAT SAVED THE MARKET
        </div>
        <div style={{ fontSize: 41, fontWeight: 700, lineHeight: 1.35, marginTop: 40, opacity: q }}>
          What did he see, that nobody else did?
        </div>
      </div>
    </div>
  );
};

// the day mood, tuned for this VM's software GL: a 1024 shadow map and no bloom pass
// (a bright day scene has no practical cores to bloom; ink, grade and DOF are untouched)
const DAY = moodOf("day");
const MOOD: MoodPreset = {
  ...DAY,
  lights: { ...DAY.lights, key: { ...DAY.lights.key, mapSize: 1024 } },
  post: { ...DAY.post, bloom: { ...DAY.post.bloom, enabled: false } },
};

export const Crash: React.FC<{ sub?: boolean }> = ({ sub = false }) => {
  const ready = useFonts();
  const g = useCurrentFrame();
  if (!ready) return <AbsoluteFill style={{ background: "#1a1220" }} />;
  const { n, fp } = sub ? subFrame(g) : { n: g, fp: g };
  const t = fp / 30;
  const tc = n / 30;
  const mood = MOOD;
  const p = poseAt(S1, BEATS, 0, t, PRMS);
  const cam = withShake(p, p.shake);

  const cart = cartState(t);
  const karim = karimState(t);
  const dev = devState(t);
  const karimHead = headOf(karim.pos, KARIM.height, KARIM.build);
  const devHead = headOf(dev.pos, DEV.height, DEV.build);

  // depth-of-field focus follows the beat's subject
  let focus: V3 = [0, cart.y + 1.7, cart.z];
  let blur = 0;
  let lightAt = karimHead;
  if (t >= lineStart(3) && t < lineStart(4)) { blur = 0.6; }
  else if (t >= lineStart(4) && t < lineStart(5)) { focus = [0, 1.3, -10]; blur = 0; lightAt = [0.8, 1.55, -9.2]; }
  else if (t >= lineStart(5) && t < lineStart(6)) { focus = devHead; blur = 1.9; lightAt = devHead; }
  else if (t >= lineStart(6) && t < lineStart(8)) { focus = [3.4, 1.0, -4.4]; blur = 1.2; lightAt = devHead; }
  else if (t >= lineStart(8) && t < lineStart(9)) { focus = [0, 0.95, -3.0]; blur = 1.0; lightAt = devHead; }
  else if (t >= lineStart(9) && t < lineStart(10)) { focus = devHead; blur = 0; lightAt = devHead; }
  else if (t >= lineStart(10)) { focus = karimHead; blur = 1.8; lightAt = karimHead; }

  const karimFC = t < 7.5 || t >= lineStart(10) ? cam.pos : undefined;
  const devFC = (t >= lineStart(5) && t < lineStart(6)) || t >= lineStart(9) ? cam.pos : undefined;

  return (
    <AbsoluteFill style={{ background: "#1a1220" }}>
      <View mood={mood} cam={cam} t={t} focus={focus} blur={blur}>
        <World />
        <HayCart />
        {[0, 1, 2, 3, 4, 5].map((i) => {
          const b = baleState(i, t);
          return <Bale key={i} p={b.p} r={b.r} />;
        })}
        <group position={[0, cart.y, cart.z]} rotation={[-SLOPE, 0, 0]}>
          <GrainCart spin={cart.spin} rope={t < T_SNAP} />
        </group>
        <group position={[-2.2, groundY(13.9), 13.9]}>
          <AnchorPost />
          {t >= T_SNAP ? <RopeOnGround /> : null}
        </group>
        <Character3D {...KARIM} position={karim.pos} yaw={karim.yaw} t={t} face={karim.face} pose={karim.pose} faceCamera={karimFC} />
        {t >= onset(10, "holding") ? <RopeInHand p={karim.pos} yaw={karim.yaw} /> : null}
        <Character3D {...DEV} position={dev.pos} yaw={dev.yaw} t={t} face={dev.face} pose={dev.pose} faceCamera={devFC} />
        {CROWD_SPECS.map((spec, i) => {
          const s = crowdState(i, t);
          return <Character3D key={i} {...spec} position={s.pos} yaw={s.yaw} t={t} face={s.face} pose={s.pose} />;
        })}
        <CastLight at={lightAt} cam={cam.pos} mood={mood} />
      </View>
      <Captions chunks={CHUNKS} t={tc} accent={ACCENT} accentColor="#ffc93a" until={lineEnd(11) + 0.35} />
      <HookBoard t={tc} />
    </AbsoluteFill>
  );
};
