import React from "react";
import { Composition } from "remotion";
import { SUB } from "./inkbeat/core/frame";
import { Crash } from "./film/Crash";

// Crash: the 50 s Short at 30 fps (sharp). CrashSub: the same at SUB x fps for motion blur
// (average with ffmpeg tmix per references/render-and-qa.md). Captions key to the output frame.
export const Root: React.FC = () => (
  <>
    <Composition id="Crash" component={Crash} durationInFrames={1500} fps={30} width={1080} height={1920} defaultProps={{ sub: false }} />
    <Composition id="CrashSub" component={Crash} durationInFrames={1500 * SUB} fps={30 * SUB} width={1080} height={1920} defaultProps={{ sub: true }} />
  </>
);
